import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-flights',
  templateUrl: './add-flights.component.html',
  styleUrls: ['./add-flights.component.css']
})
export class AddFlightsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
