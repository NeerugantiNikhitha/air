export class User {
    firstName: string;
    lastName: string;
    gender: string;
    emailId: string;
    mobileNumber: number;
    age: number;
    password: string;
    userId:number;
}