import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-flight',
  templateUrl: './delete-flight.component.html',
  styleUrls: ['./delete-flight.component.css']
})
export class DeleteFlightComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
